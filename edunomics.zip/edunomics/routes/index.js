const express=require ("express");
const  app=expres();
app.get('/',(req,res)=>{res.send("hello")});
module.exports=app;