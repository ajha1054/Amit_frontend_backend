const express=require("express");
const app=express();
var gg=1
var bodyparser =require("body-parser");
var s=[];
var t=[];
var c={};


port=process.env.port||5000
//


app.set('view engine','ejs');
app.use(bodyparser.urlencoded({ extended: false }));
app.use(express.json()) ;


app.get('/',(req,res)=>
{
    
    res.render('plot',{
        height:req.body.Height,
        coeff:req.body.coeff

    })
});

app.post('/',(req,res)=>
{
    console.log(req.body)
    
    x=parseFloat(req.body.Height);
    x=x.toFixed(2)
    r=parseFloat(req.body.vol)
    r=r.toFixed(2);
    s[0]=x
t[0]=(0)
var count=1;


   
var count1=1;
while(x>=0.0001)
{   s[count1]=0
    t[count1]=t[count1-1]+(Math.sqrt((2*s[count1-1])/10))
    count1++
    x=(r*x/100).toFixed(2);
    s[count1]=x
    t[count1]=t[count1-1]+(Math.sqrt((2*s[count1])/10))
    count1++
    count++;


   
}
  

    var obj = {
        table: []
     };
     var obj1={
         table:[]
     }
     var i=0;
     gg++;
   
     for(i=0;i<count1;i++)
     {
        obj1.table.push({ x: s[i], y:t[i]});

     }
    //  for(i=0;i<count1;i++)
    //  {
    //     obj.table.push({bounces:count},{ x: s[i], y:t[i]});

    //  }
     var json = JSON.stringify(obj)+"\n\n\n";
      var json1 = JSON.stringify(obj1);
      var fs = require('fs');
     fs.writeFile('myjson.json', json1, 'utf8', err=>{
         if(err)
         {console.log(err)}
         console.log("file has been created");
     });
    //  fs.writeFile('all-records.json', json, 'utf8', err=>{
    //     if(err)
    //     {console.log(err)}
    //     console.log("file has been created");
    // });
     fs.readFile('all-records.json', 'utf8', function readFileCallback(err, data){
        if (err){
            console.log("Data could not be found");
        } else {
        obj = JSON.parse(data);
        //res.send(obj) //now it an object
        for(i=0;i<count1;i++)
        {
           obj.table.push({obsevation:gg},{bounces:count},{ x: s[i], y:t[i]});
   
        }
       //add some data
       json = JSON.stringify(obj); //convert it back to json
       fs.writeFile('all-records.json', json, 'utf8', (err)=>{
           if(err)
           {console.log(err)}
           else
           console.log("file created");
       }); // write it back 
    }});



       res.render('plot1',{
        height:req.body.Height,
        coeff:req.body.vol

    })

    //res.send(obj)
});
app.get('/api',(req,res)=>{
    var obj = {
        table: []
     };
    var fs = require('fs');
    

    
    fs.readFile('myjson.json', 'utf8', function readFileCallback(err, data){
        if (err){
            res.send("Data could not be found");
        } else {
        obj = JSON.parse(data);
        res.send(obj) //now it an object
       // obj.table.push({id: 2, square:3}); //add some data
       // json = JSON.stringify(obj); //convert it back to json
       // fs.writeFile('myjsonfile.json', json, 'utf8', callback); // write it back 
    }});


});
app.get('/all-records',(req,res)=>{
    var obj = {
        table: []
     };
    var fs = require('fs');
    

    
    fs.readFile('all-records.json', 'utf8', function readFileCallback(err, data){
        if (err){
            res.send("Data could not be found");
        } else {
        obj = JSON.parse(data);
        res.send(obj) //now it an object
       // obj.table.push({id: 2, square:3}); //add some data
       // json = JSON.stringify(obj); //convert it back to json
       // fs.writeFile('myjsonfile.json', json, 'utf8', callback); // write it back 
    }});

})


    app.listen(port, console.log('server started on port',port));